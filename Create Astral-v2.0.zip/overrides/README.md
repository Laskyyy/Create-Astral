# Create-Astral

Dev Github for the modpack Create: Astral

https://www.curseforge.com/minecraft/modpacks/create-astral

https://discord.gg/mNeHyuZdqm

Does not include mods, or most configs.
Just pack specific stuff which is used when compiling the pack for curseforge.
